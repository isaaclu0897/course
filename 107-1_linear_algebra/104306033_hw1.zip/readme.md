線性代數作業(一)程式說明
===

1. 自我介紹
開課班級：資工二
班級：四機四乙
學號：104306033 
姓名：呂浩維

---

2. Development environment：
    Operating system： Ubuntu 18.04 LTS
    Python version： 3.6.5
    Spyder version： 3.2.8
    numpy version： 1.13.3
    encoding： utf-8
    
---

3. 如何執行

在這個資料夾裡，除了 readme.md這個檔案之外，您將會看到其他幾個檔案。
分別是output1、output2，這是兩個執行範例，
還有case1~case6的結果，
以及LA_hw1.py，這是源代碼。

您只需要在終端機中使用 $ python LA_hw1.py 便可運行腳本，或是直接在IDE執行該檔案
console 會自動輸出case 1～case 6.

note: 想看操作步驟可以把,log_method(func)裡的三行註解打開,你可以看到所有化簡的過程



---

4. 撰寫想法

""" my idea

in this class, i will divide it into three step.
like forward_phase, back_phase, and get_solution of function.
but no just like that, you need to three elementary row operate,
such as interchange, scalong and replacement, then i define that method. 

so we just need to divide and conqer, then we can get the final solution,

note: the reduced echelon from actually is result of back_phase.
"""

